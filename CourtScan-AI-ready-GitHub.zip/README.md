# CourtScan Personal – AI-ready (iPhone)

## Telepítés GitHub Pagesre (0 Ft)
1. Hozz létre ingyenes GitHub-fiókot: https://github.com/signup
2. Készíts `courtscan-personal` nevű **public** repositoryt.
3. Add hozzá az `index.html` és `manifest.webmanifest` fájlokat a repository gyökerébe (Add file → Upload files → Commit changes).
4. Settings → Pages → Build and deployment → Deploy from a branch → `main`, `/(root)` → Save.
5. Pár perc múlva a címed: `https://FELHASZNALONEVED.github.io/courtscan-personal/`.
6. iPhone Safari: Megosztás → Hozzáadás a Főképernyőhöz.

**Fontos:** A GitHub Pages oldal publikus, de a kártyáid alapértelmezésben a helyi böngészőtárhelyre kerülnek. Az appban készíts rendszeresen JSON biztonsági mentést. A böngészőadatok törlése elveszítheti a helyi adatokat, és nincs eszközök közti szinkronizálás. A képek feltöltése csak akkor hagyja el a telefont, ha később bekapcsolod az AI módot.

## AI mód – későbbre előkészítve
A kézi használat 0 Ft. Az AI gomb csak akkor küld képeket, ha beállítasz egy saját HTTPS API-végpontot a ⚙ AI kapcsolat menüben.
Az endpoint szerződése: `POST` JSON `{front: 'data:image/jpeg;base64,...', back: 'data:image/jpeg;base64,...'}`; opcionális `Authorization: Bearer <személyes hozzáférési kód>`; válasz JSON: `{name,year,set,number,variant,condition,notes}`.
**Ne írj OpenAI vagy egyéb szolgáltatói API-kulcsot a böngészős felületbe.** A szolgáltatói kulcsot a később létrehozandó backend titkos beállításában tárold. Az AI-használatnak lehet díja, az ingyenes szerverkvóta nem jelenti az AI ingyenességét. Szükség lesz megfelelő jogosultságkezelésre, használati limitekre és a végpont CORS-beállításaira is.

## Megjegyzés
A jelenlegi app nem rendelkezik automatikus eBay/SportsCardsPro árlekéréssel; a mentett árak korábbi pillanatképek vagy kézi adatok.
